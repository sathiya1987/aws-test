# AWS Network setup for Non-prod
We can create two vpc-A and VPC-B with peering enabled

# terraform Commands to execute
  terraform fmt
  terraform init
  terraform plan -out=network_nonprod.plan
  terraform apply network_nonprpd.plan
