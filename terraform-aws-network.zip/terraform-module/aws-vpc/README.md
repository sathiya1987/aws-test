# AWS VPC Terraform Module
 This module use to create VPC,Subnets,NACLs,RouteTables,VPC peering,NAT,DHCP,VPC FLowlogs.

# terraform Commands
  terraform fmt
  terraform-docs markup table
  terraform init
  terraform plan -out=network.plan
  terraform apply network.plan

# Future plan
 VPN,VPC Endpoints